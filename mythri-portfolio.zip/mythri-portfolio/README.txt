# Mythri Reddy Portfolio

A modern, responsive personal portfolio built with:
- HTML5
- CSS3
- Vanilla JavaScript

## Folder structure

mythri-portfolio/
├── index.html
├── style.css
├── script.js
└── assets/

## Run in VS Code

1. Open this folder in VS Code.
2. Install the "Live Server" extension.
3. Right-click `index.html`.
4. Select "Open with Live Server".

You can also simply double-click `index.html` to open it in a browser.

## Personalization

- Replace the `MR` avatar with your photo if you want.
- Add your GitHub/LinkedIn links in the Contact section.
- Add more projects as you complete them.
- Add project links/buttons when your projects are hosted.
